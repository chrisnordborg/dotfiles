﻿=== Red Gem Cursor Set ===

By: whitesoul

Download: http://www.rw-designer.com/cursor-set/red-gem

Author's decription:

赤い宝石
레드 보석
紅色寶石
Красный камень
Versión roja de Gema Blanca

[[cursor-set/whitegem|Original cursors]]

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.