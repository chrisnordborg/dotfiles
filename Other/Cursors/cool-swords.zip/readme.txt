﻿=== Cool swords Cursor Set ===

By: deadly bro

Download: http://www.rw-designer.com/cursor-set/cool-swords

Author's decription:

i made these to work with the cool shields icon set that i made and actually they are good with the shields and also cool there is red.blue and golden.and other more they are good looking too so (hope they are good)        
                 (have a good day)

DEADLY BRO    

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.