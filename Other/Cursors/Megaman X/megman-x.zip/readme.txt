﻿=== Megaman X Cursor Set ===

By: Olimar (http://www.rw-designer.com/user/15964) chupablo.c@hotmail.com

Download: http://www.rw-designer.com/cursor-set/megman-x

Author's decription:

I have done the classic megaman cursors, but why not do the X series?. Enjoy.




==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.