﻿=== Amethyst in Diamonds Cursor Set ===

By: winger (http://www.rw-designer.com/user/16070)

Download: http://www.rw-designer.com/cursor-set/amethyst-in-diamonds

Author's decription:

From photos of the real gemstones.  

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.