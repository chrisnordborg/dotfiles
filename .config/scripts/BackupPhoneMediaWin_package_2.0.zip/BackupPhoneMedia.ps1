# Add Windows Forms for popups
Add-Type -AssemblyName System.Windows.Forms

# Set backup destination
$backupRoot = "$env:USERPROFILE\Pictures"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$destFolder = Join-Path $backupRoot $timestamp

# Create destination directory
New-Item -ItemType Directory -Path $destFolder -Force | Out-Null

# Access Shell COM object
$shell = New-Object -ComObject Shell.Application

# Check all namespaces for connected devices
$allNamespaces = @(4, 17, 18, 19)  # Common namespaces for removable drives, devices, etc.

$devicesFound = @()

foreach ($namespaceId in $allNamespaces) {
    $namespace = $shell.Namespace($namespaceId)
    if ($namespace) {
        $devices = $namespace.Items()
        $devicesFound += $devices
    }
}

if ($devicesFound.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("No devices found. Please connect a device and try again.", "Device Not Detected", "OK", "Error")
    exit
}

# Find the phone device (by type hint)
$phone = $devicesFound | Where-Object {
    $_.Type -like "*Portable*" -or
    $_.Type -like "*MTP*" -or
    $_.Type -like "*Removable*" -or
    $_.Type -like "*Mobiltelefon*"
}

if ($null -eq $phone) {
    [System.Windows.Forms.MessageBox]::Show("Ingen telefon �r ansluten. V�nligen anslut en telefon.", "Ingen telefon hittad", "OK", "Error")
    exit
}

# Get phone folders, locate "Intern lagring"
$phoneFolders = $phone.GetFolder.Items()
$internalStorage = $phoneFolders | Where-Object { $_.Name -eq "Intern lagring" }

if ($null -eq $internalStorage) {
    [System.Windows.Forms.MessageBox]::Show("Could not find 'Intern lagring' folder on the phone.", "Folder Not Found", "OK", "Error")
    exit
}

# Find DCIM folder inside "Intern lagring"
$internalStorageItems = $internalStorage.GetFolder.Items()
$dcim = $internalStorageItems | Where-Object { $_.Name -eq "DCIM" }

if ($null -eq $dcim) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta mappen DCIM i telefonen.", "Ingen mapp hittad", "OK", "Error")
    exit
}

# Find Camera folder inside DCIM
$cameraFolder = $dcim.GetFolder.Items() | Where-Object { $_.Name -eq "Camera" }

if ($null -eq $cameraFolder) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta undermappen 'Camera' inuti DCIM.", "Ingen undermapp hittad", "OK", "Error")
    exit
}

# Copy entire Camera folder to $destFolder
Write-Host "Copying 'Camera' folder to $destFolder..."

$phoneNamespace = $shell.Namespace($dcim.Path)
$destNamespace = $shell.Namespace($destFolder)

# Use CopyHere on the Camera folder object (not items) to copy whole folder structure
$destNamespace.CopyHere($dcim.GetFolder.ParseName("Camera"))

# Wait some time to let copy finish (adjust as needed)
Start-Sleep -Seconds 10

# Define path to the copied Camera folder inside destination
$copiedCameraPath = Join-Path $destFolder "Camera"

if (Test-Path $copiedCameraPath) {
    # Move all files from Camera folder to $destFolder
    Get-ChildItem -Path $copiedCameraPath -File | ForEach-Object {
        $targetFile = Join-Path $destFolder $_.Name
        Write-Host "Moving file: $($_.Name) to $destFolder"
        Move-Item -Path $_.FullName -Destination $targetFile -Force
    }

    # Move all subfolders from Camera folder to $destFolder
    Get-ChildItem -Path $copiedCameraPath -Directory | ForEach-Object {
        $targetFolder = Join-Path $destFolder $_.Name
        Write-Host "Moving folder: $($_.Name) to $destFolder"
        Move-Item -Path $_.FullName -Destination $targetFolder -Force
    }

    # Remove the empty Camera folder
    Write-Host "Removing empty Camera folder..."
    Remove-Item -Path $copiedCameraPath -Force -Recurse
}
else {
    Write-Host "Camera folder not found in destination!"
}

[System.Windows.Forms.MessageBox]::Show("Backup av bilder klar. De �r sparade under:`n$destFolder", "Klar", "OK", "Information")

Write-Host "`nPress any key to close the terminal..."
$null = Read-Host
