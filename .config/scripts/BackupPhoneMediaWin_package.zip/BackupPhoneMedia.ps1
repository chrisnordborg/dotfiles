# Add Windows Forms for popups
Add-Type -AssemblyName System.Windows.Forms

# Set backup destination
$backupRoot = "$env:USERPROFILE\MediaBackups"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$destFolder = Join-Path $backupRoot $timestamp

# Create destination directory
New-Item -ItemType Directory -Path $destFolder -Force | Out-Null

# Access Shell COM object
$shell = New-Object -ComObject Shell.Application
$computer = $shell.Namespace(17) # This PC

# Try to find mobile phone device (Portable Devices)
$phone = $computer.Items() | Where-Object { $_.Type -like "*Portable*" }

if ($null -eq $phone) {
    [System.Windows.Forms.MessageBox]::Show("No mobile phone connected. Please connect your phone.", "Phone Not Detected", "OK", "Error")
    exit
}

# Attempt to locate DCIM folder (may require adjusting names depending on phone model)
$dcim = $phone.GetFolder.Items() |
    Where-Object { $_.Name -eq "Internal shared storage" } |
    ForEach-Object { $_.GetFolder.Items() | Where-Object { $_.Name -eq "DCIM" } } |
    Select-Object -First 1

if ($null -eq $dcim) {
    [System.Windows.Forms.MessageBox]::Show("Could not find DCIM folder on the phone.", "Folder Not Found", "OK", "Error")
    exit
}

# Copy media from DCIM to backup folder
$items = $dcim.GetFolder.Items()
foreach ($item in $items) {
    $sourceFolder = $item.GetFolder
    $files = $sourceFolder.Items()

    foreach ($file in $files) {
        try {
            $targetPath = Join-Path $destFolder $file.Name
            $file.InvokeVerb("Copy")
            Start-Sleep -Milliseconds 100
            $shell.Namespace($destFolder).Self.InvokeVerb("Paste")
            Start-Sleep -Seconds 1
        }
        catch {
            continue
        }
    }
}

[System.Windows.Forms.MessageBox]::Show("Backup completed to:`n$destFolder", "Success", "OK", "Information")
