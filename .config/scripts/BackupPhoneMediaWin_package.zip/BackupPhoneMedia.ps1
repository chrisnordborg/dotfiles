﻿
# Copy function
function Copy-SubfolderFromInternalStorage {
    param (
        [System.__ComObject]$sourceFolder,     # Shell folder object
        [string]$destinationFolder             # Local path
    )

    $folderName = $sourceFolder.Name
    Write-Host "Copying '$folderName' folder to $destinationFolder..."

    $destNamespace = $shell.Namespace($destinationFolder)

    if (-not $sourceFolder -or -not $destNamespace) {
        Write-Host "Failed to access source or destination namespace."
        return
    }

    # Copy the entire folder
    $destNamespace.CopyHere($sourceFolder, 16)
    Start-Sleep -Seconds 10

    Write-Host "'$folderName' copied."
    $global:copied = $true
}
################################################################################

# Add Windows Forms for popups
Add-Type -AssemblyName System.Windows.Forms

# Set backup destination
$backupRoot = "$env:USERPROFILE\Pictures"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$destFolder = Join-Path $backupRoot "Telefon-backup $timestamp"


# Create destination directory
New-Item -ItemType Directory -Path $destFolder -Force | Out-Null

# Access Shell COM object
$shell = New-Object -ComObject Shell.Application

# Check all namespaces for connected devices
$allNamespaces = @(4, 17, 18, 19)
$devicesFound = @()

foreach ($namespaceId in $allNamespaces) {
    $namespace = $shell.Namespace($namespaceId)
    if ($namespace) {
        $devices = $namespace.Items()
        $devicesFound += $devices
    }
}

if ($devicesFound.Count -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("No devices found. Please connect a device and try again.", "Device Not Detected", "OK", "Error")
    exit
}

# Find the phone device
$phone = $devicesFound | Where-Object {
    $_.Type -like "*Portable*" -or
    $_.Type -like "*MTP*" -or
    $_.Type -like "*Removable*" -or
    $_.Type -like "*Mobiltelefon*"
}

if ($null -eq $phone) {
    [System.Windows.Forms.MessageBox]::Show("Ingen telefon är ansluten. Vänligen anslut en telefon.", "Ingen telefon hittad", "OK", "Error")
    exit
}

# Get "Intern lagring"
$phoneFolders = $phone.GetFolder.Items()
$internalStorage = $phoneFolders | Where-Object { $_.Name -eq "Intern lagring" }

if ($null -eq $internalStorage) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta mappen 'Intern lagring' på telefonen.", "Mapp ej hittad", "OK", "Error")
    exit
}

$internalStorageItems = $internalStorage.GetFolder().Items()
$error = $false
$copied = $false

################################################################################
# Find DCIM and Camera
$dcim = $internalStorageItems | Where-Object { $_.Name -eq "DCIM" }
if ($null -eq $dcim) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta mappen DCIM i telefonen.", "Ingen mapp hittad", "OK", "Error")
    $error = $true
} else {
    $cameraFolder = $dcim.GetFolder().Items() | Where-Object { $_.Name -eq "Camera" }
    if ($null -eq $cameraFolder) {
        [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta undermappen 'Camera' inuti DCIM.", "Ingen undermapp hittad", "OK", "Error")
        $error = $true
    } else {
        Write-Host "Found Camera Images folder!"
        Copy-SubfolderFromInternalStorage -sourceFolder $cameraFolder -destinationFolder $destFolder
        $copied = $true
    }
}

################################################################################
# Pictures
$pictures = $internalStorageItems | Where-Object { $_.Name -eq "Pictures" }
if ($null -eq $pictures) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta mappen Pictures i telefonen.", "Ingen mapp hittad", "OK", "Error")
    $error = $true
} else {
    Write-Host "Found Pictures folder!"
    Copy-SubfolderFromInternalStorage -sourceFolder $pictures -destinationFolder $destFolder
    $copied = $true
}

################################################################################
# WhatsApp Images
$android = $internalStorage.GetFolder().Items() | Where-Object { $_.Name -eq "Android" }
if ($android) {
    $media = $android.GetFolder().Items() | Where-Object { $_.Name -eq "media" }
    if ($media) {
        $comWhatsapp = $media.GetFolder().Items() | Where-Object { $_.Name -eq "com.whatsapp" }
        if ($comWhatsapp) {
            $whatsapp = $comWhatsapp.GetFolder().Items() | Where-Object { $_.Name -eq "WhatsApp" }
            if ($whatsapp) {
                $mediaFolder = $whatsapp.GetFolder().Items() | Where-Object { $_.Name -eq "Media" }
                if ($mediaFolder) {
                    $images = $mediaFolder.GetFolder().Items() | Where-Object { $_.Name -eq "WhatsApp Images" }
                    if ($images) {
                        Write-Host "Found WhatsApp Images folder!"
                    }
                }
            }
        }
    }
}
if ($null -eq $images) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta mappen WhatsApp Images i telefonen.", "Ingen mapp hittad", "OK", "Error")
    $error = $true
} else {
    Copy-SubfolderFromInternalStorage -sourceFolder $images -destinationFolder $destFolder
    $copied = $true
}

################################################################################
# Summary message
if (-not $error -and $copied) {
    [System.Windows.Forms.MessageBox]::Show("Backup av bilder klar. De är sparade under:`n$destFolder", "Klar", "OK", "Information")
} elseif ($error -and $copied) {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta en eller flera undermappar. Vissa bilder har kopierats", "Viss undermapp ej hittad", "OK", "Error")
} else {
    [System.Windows.Forms.MessageBox]::Show("Kunde inte hitta någon mapp.", "Inga mappar hittade", "OK", "Error")
}

Write-Host "`nPress any key to close the terminal..."
$null = Read-Host


