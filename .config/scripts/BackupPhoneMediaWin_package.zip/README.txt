﻿Backup Phone Media Shortcut Instructions:


1. Copy the .lnk and .ps1 files to your desktop.
2. Double-clicking on the .lnk file will run your script.
3. (Optional) Right-click the shortcut > Properties > set Run: Minimized. If set to minimized, a terminal window will not open when running the script.

To run the script successfully, you may need to enable script execution:
Open PowerShell and run:
   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned

#############################################################

If you can't copy the .lnk file, or don't have one.
1. Right-click on your Desktop > New > Shortcut.
2. In the "Type the location of the item" box, paste the following (change filepath if need be):
   powershell.exe -ExecutionPolicy Bypass -File "%USERPROFILE%\Desktop\BackupPhoneMedia.ps1"
3. Click Next, choose a name for the shortcut (maybe "Backup Phone Media").
